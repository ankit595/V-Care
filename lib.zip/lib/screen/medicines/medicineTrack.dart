import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class MedicineCalendar extends StatefulWidget {
  @override
  _MedicineCalendarState createState() => _MedicineCalendarState();
}

class _MedicineCalendarState extends State<MedicineCalendar> {
  late DateTime currentDate;
  late DateTime firstDayOfMonth;
  late int daysInMonth;
  List<DateTime> medicineTakenDates = [
  ];
  List<DateTime> medicineSkippedDates = [
  ];

  @override
  void initState() {
    super.initState();
    currentDate = DateTime.now();
    firstDayOfMonth = DateTime(currentDate.year, currentDate.month, 1);
    daysInMonth = DateTime(currentDate.year, currentDate.month + 1, 0).day;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Medicine Calendar',
          style: TextStyle(
            fontFamily: "Itim",
            fontSize: 22,
          ),
        ),
      ),
      body: Column(
        children: [
          TableCalendar(
            firstDay: firstDayOfMonth,
            lastDay: firstDayOfMonth.add(Duration(days: daysInMonth - 1)),
            focusedDay: currentDate,
            calendarFormat: CalendarFormat.month,
            onPageChanged: (focusedDay) {
              setState(() {
                firstDayOfMonth = focusedDay;
                daysInMonth = DateTime(focusedDay.year, focusedDay.month + 1, 0).day;
              });
            },
            daysOfWeekStyle: DaysOfWeekStyle(
              weekdayStyle: TextStyle(color: Colors.black, fontFamily: "Itim",),
              weekendStyle: TextStyle(color: Colors.black, fontFamily: "Itim",),
            ),
            calendarStyle: CalendarStyle(
              defaultTextStyle: TextStyle(color: Colors.black, fontFamily: "Itim",),

              todayDecoration: BoxDecoration(
                color: Colors.blue[500],
                shape: BoxShape.circle,
              ),
            ),
            headerStyle: HeaderStyle(
              titleTextStyle: TextStyle(fontSize: 20, fontFamily: "Itim",),
            ),
            rowHeight: 40,
            calendarBuilders: CalendarBuilders(
              defaultBuilder: (context, date, _) {
                Color color = Colors.white;
                print('Checking date: $date');
                if (medicineTakenDates.contains(DateTime(date.year, date.month, date.day))) {
                  color = Colors.green;
                } else if (medicineSkippedDates.contains(DateTime(date.year, date.month, date.day))) {
                  color = Colors.orange;
                }
                return Container(
                  height: 35,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color,
                  ),
                  child: Center(
                    child: Text(
                      date.day.toString(),
                      style: TextStyle(color: Colors.black, fontFamily: "Itim",),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
