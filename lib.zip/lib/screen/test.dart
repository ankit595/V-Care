import 'package:flutter/material.dart';

class Test_Stack extends StatefulWidget {
  const Test_Stack({super.key});

  @override
  State<Test_Stack> createState() => _Test_StackState();
}

class _Test_StackState extends State<Test_Stack> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child:Stack(
          children: <Widget>[
            Positioned(
              top: 0,
              child: Container(
                height: MediaQuery.of(context).size.height*.4,
                width: MediaQuery.of(context).size.width,
                color: Colors.brown,

              ),
            ),
            Positioned(
              bottom: 0,
              child: Container(
                height: MediaQuery.of(context).size.height*.65,
                width: MediaQuery.of(context).size.width,
                color: Colors.orange,
              ),
            ),

          ],
        ),
      ),
    );
  }
}